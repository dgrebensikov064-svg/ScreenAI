package com.example.screenai

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.*
import android.widget.*
import com.googlecode.tesseract.android.TessBaseAPI
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var recognizer: SpeechRecognizer? = null
    private lateinit var bubble: Button
    private lateinit var panel: LinearLayout
    private lateinit var input: EditText
    private lateinit var answer: TextView
    private var w = 0
    private var h = 0

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        val code = intent?.getIntExtra("code", 0) ?: return START_NOT_STICKY
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        setupCapture(code, data)
        setupOverlay()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val ch = "screenai"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Screen AI", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("Screen AI работает")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    // ---------- screen capture ----------
    private fun setupCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, main)
        val dm = resources.displayMetrics
        w = dm.widthPixels; h = dm.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vDisplay = projection!!.createVirtualDisplay(
            "screenai", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, main
        )
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        val p = img.planes[0]
        val rowPad = p.rowStride - p.pixelStride * w
        val full = Bitmap.createBitmap(w + rowPad / p.pixelStride, h, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(p.buffer)
        img.close()
        return Bitmap.createBitmap(full, 0, 0, w, h)
    }

    // ---------- overlay UI ----------
    private fun setupOverlay() {
        val type = TYPE_APPLICATION_OVERLAY

        bubble = Button(this).apply { text = "AI" }
        val bp = WindowManager.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, type, FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.END; y = 300 }
        wm.addView(bubble, bp)

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xEE202020.toInt())
            setPadding(24, 24, 24, 24)
            visibility = View.GONE
        }
        input = EditText(this).apply {
            hint = "Запрос (например: реши то, что на экране)"
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF999999.toInt())
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val mic = Button(this).apply { text = "🎤"; setOnClickListener { listen() } }
        val send = Button(this).apply {
            text = "Отправить"
            setOnClickListener { val q = input.text.toString().trim(); if (q.isNotEmpty()) ask(q) }
        }
        val close = Button(this).apply { text = "✕"; setOnClickListener { stopSelf() } }
        row.addView(mic); row.addView(send); row.addView(close)
        answer = TextView(this).apply { setTextColor(0xFFFFFFFF.toInt()); textSize = 15f; setTextIsSelectable(true) }
        val scroll = ScrollView(this).apply { addView(answer) }
        panel.addView(input); panel.addView(row)
        panel.addView(scroll, LinearLayout.LayoutParams(-1, (h * 0.35).toInt()))

        val pp = WindowManager.LayoutParams(-1, WRAP_CONTENT, type, 0, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.BOTTOM; softInputMode = SOFT_INPUT_ADJUST_RESIZE }
        wm.addView(panel, pp)

        bubble.setOnClickListener {
            panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
    }

    // ---------- main flow ----------
    private fun ask(q: String) {
        answer.text = "Читаю экран…"
        panel.visibility = View.INVISIBLE   // чтобы панель не попала на скриншот
        bubble.visibility = View.INVISIBLE
        main.postDelayed({
            val bmp = grab()
            panel.visibility = View.VISIBLE
            bubble.visibility = View.VISIBLE
            if (bmp == null) { answer.text = "Не удалось снять экран"; return@postDelayed }
            thread {
                try {
                    val text = ocr(bmp)
                    main.post { answer.text = "Думаю…" }
                    val reply = deepseek(q, text)
                    main.post { answer.text = reply }
                } catch (e: Exception) {
                    main.post { answer.text = "Ошибка: ${e.message}" }
                }
            }
        }, 350)
    }

    private fun ocr(bmp: Bitmap): String {
        val dir = File(filesDir, "tess")
        val td = File(dir, "tessdata").apply { mkdirs() }
        for (l in listOf("rus", "eng")) {
            val f = File(td, "$l.traineddata")
            if (!f.exists()) assets.open("tessdata/$l.traineddata").use { i -> f.outputStream().use { i.copyTo(it) } }
        }
        val api = TessBaseAPI()
        check(api.init(dir.absolutePath, "rus+eng")) { "Tesseract не запустился" }
        api.setImage(bmp)
        val t = api.utf8Text ?: ""
        api.recycle()
        return t
    }

    private fun deepseek(q: String, screen: String): String {
        val key = getSharedPreferences("s", 0).getString("key", "") ?: ""
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content",
                "Пользователь присылает текст, распознанный с экрана телефона (OCR, возможны ошибки), и запрос. Отвечай на языке запроса, по делу."))
            .put(JSONObject().put("role", "user").put("content", "Текст с экрана:\n$screen\n\nЗапрос: $q"))
        val body = JSONObject().put("model", "deepseek-chat").put("messages", messages)
        val c = URL("https://api.deepseek.com/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Content-Type", "application/json")
        c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = c.responseCode < 400
        val s = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
        if (!ok) throw Exception(s)
        return JSONObject(s).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }

    // ---------- voice ----------
    private fun listen() {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) {
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null) { input.setText(t); ask(t) }
            }
            override fun onError(e: Int) { answer.text = "Голос не распознан (код $e)" }
            override fun onReadyForSpeech(p: Bundle?) { answer.text = "Слушаю…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
        recognizer!!.startListening(i)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        runCatching { wm.removeView(bubble); wm.removeView(panel) }
        vDisplay?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
}
